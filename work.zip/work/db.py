import sqlite3

connection = None


def get_connection():
    global connection
    if connection is None:
        connection = sqlite3.connect('database.db')
    return connection


def init_db(force: bool = True):
    conn = get_connection()
    c = conn.cursor()
    if force:
        c.execute('DROP TABLE IF EXISTS user_message')

    c.execute('''
        CREATE TABLE IF NOT EXISTS user_message (
            id           INTEGER PRIMARY KEY,
            star         TEXT NOT NULL,
            planetcount  TEXT NOT NULL
        )
    ''')

    conn.commit()


def add_message(star: str, planetcount: str):
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        'INSERT INTO user_message (star, planetcount) VALUES (?, ?)',
        (star, planetcount))
    conn.commit()


if __name__ == '__main__':
    init_db(force=False)
